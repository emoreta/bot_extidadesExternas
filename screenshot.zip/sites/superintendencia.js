import puppeteer from 'puppeteer';
import fs from 'fs';
import path from 'path';


const config = {
    lang: "eng",
    oem: 1,
    psm: 3,
}

function delay(time) {
    return new Promise(function (resolve) {
        setTimeout(resolve, time)
    });
}
const Superintendencia = async (cedula) => {
    console.log("Processing Supa");
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(0);
    let wellAdded = [];
    let processed = [];
    let error = [];
    console.log(`Reading page`);
    await page.goto(`https://appweb.superbancos.gob.ec/ssl/registro/registro.jsf`);
    await page.waitForSelector('#LB');
    await page.waitForSelector('#cerrar');
    await page.waitForSelector('#cerrar');
    await delay(300);
    await page.click('#cerrar');
    await page.click('#cerrar');
    await page.click('#cerrar');

    await page.evaluate(() => {

        $("#cerrar").click(function () {
            $("#fndLB").fadeOut();
            $("#LB").fadeOut("slow");
            $("#cerrar").fadeOut("slow");
        });

    });
    await delay(300);
    await page.waitForSelector('#frmConsulta\\:frmUsuario\\:tipoIden\\:socc');
    await page.select('#frmConsulta\\:frmUsuario\\:tipoIden\\:socc', 'C')

    await delay(2000);
    //await delay(300);
    /*await page.keyboard.press("Enter");*/
    //await page.keyboard.press("Tab");
    //await page.keyboard.press("Tab");
    await page.waitForSelector('#frmConsulta\\:frmUsuario\\:nIden\\:itcc');
    await page.type('#frmConsulta\\:frmUsuario\\:nIden\\:itcc', '1718921362');

    await page.waitForSelector('#frmConsulta\\:frmUsuario\\:fCedInputDate');
    /*//await page.type('#frmConsulta\\:frmUsuario\\:fCedInputDate','01/01/2023');
    await page.fill("#frmConsulta\\:frmUsuario\\:fCedInputDate", "01/01/2023");*/
    await page.$eval('#frmConsulta\\:frmUsuario\\:fCedInputDate', e => e.setAttribute("value", "2018-01-01"))


    await page.waitForSelector('#frmConsulta\\:frmUsuario\\:nCorreo\\:itcc');
    await page.type('#frmConsulta\\:frmUsuario\\:nCorreo\\:itcc', 'edixavi@hotmail.com');

    await page.waitForSelector('#frmConsulta\\:frmUsuario\\:cap\\:itcc');
    await page.type('#frmConsulta\\:frmUsuario\\:cap\\:itcc', '12345');

    await page.waitForSelector('#frmConsulta\\:frmUsuario\\:cond\\:itcc');
    await page.$eval('#frmConsulta\\:frmUsuario\\:cond\\:itcc', check => check.checked = true);
    /*await page.evaluate(() => {
       document.querySelector("#frmConsulta\\:frmUsuario\\:cond\\:itcc").parentElement.click();
     });*/
    //await delay(10000);
    //await page.waitForNavigation();


    //await page.waitForSelector('#frmConsulta\:frmUsuario\:btnGuardar');

    /*console.log(
        page.querySelector('[id="#frmConsulta\:frmUsuario\:btnGuardar"] ')
      );*/
    //await page.waitFor('//*[@id="frmConsulta:frmUsuario:btnGuardar"]')

    const signIn = await page.waitForXPath('//*[@id="frmConsulta:frmUsuario:btnGuardar"]');

    await Promise.all([
        signIn.evaluate(el => el.click()),
        page.waitForNavigation()
    ]);

    //await page.click('//*[@id="frmConsulta:frmUsuario:btnGuardar"]');
    /*page.$eval('#frmConsulta\:frmUsuario\:btnGuardar', element =>
        element.click()
    );*/
    /*await Promise.all([
        page.$eval(`#frmConsulta\:frmUsuario\:btnGuardar`, element =>
          element.click()
        ),
        await page.waitForNavigation(),
      ]);*/


    //await delay(2000);


    await page.waitForNavigation();





}
export default Superintendencia;